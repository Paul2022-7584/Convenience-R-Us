<?php
session_start();
?>

<!DOCTYPE html PUBLIC "-//W3C//DTD XHTML 1.0 Strict//EN" "http://www.w3.org/TR/xhtml1/DTD/xhtml1-strict.dtd">
<html xmlns="http://www.w3.org/1999/xhtml">
<head>
    <!-- Meta information for search engines -->
    <meta http-equiv="Content-Type" content="text/html; charset=UTF-8" />
    <meta name="description" content="Welcome to Convenience-R-Us - Your One-Stop Grocery Chain" />
    <meta name="keywords" content="Convenience-R-Us, grocery store, convenience store, groceries, food" />
    <title>Convenience-R-Us</title>
    <link rel="stylesheet" type="text/css" href="styles.css" />
</head>
<body>
    <header>
	<!-- Page header with the main title -->
	<h1>Welcome to Convenience-R-Us!</h1>
    </header>

    <nav>
	<ul>
	    <li><a href="index.php">Home</a></li>
	    <!-- Navigation menu for internal links -->
	    <li><a href="module1.php">Module 1: Week 1 Foundations</a></li>
	    <li><a href="module1Pt2.php">Module 1: Week 1 Variables</a></li>
	    <li><a href="module2.php">Module 2: Week 2 Forms</a></li>
	    <li><a href="module3.php">Module 3: Week 3 Arrays</a></li>
	    <li><a href="module4.php">Module 4: Week 4 Sessions</a></li>
	    <li><a href="module5.php">Module 5: Week 5 CMS Sessions</a></li>
	    <li><a href="module6.php">Module 6: Week 6 Database</a></li>
	    <li><a href="module8.php">Module 8: Week 8 CMS Database</a></li>
	</ul>
    </nav>

    <main>
	<!-- Main content section for home page -->
	<section class="content">
	    <h2>About Convenience-R-Us</h2>
	    <p>Welcome to Convenience-R-Us, your one-stop grocery chain for all your food and household needs. We provide a wide range of high-quality products, weekly specials, and convenient locations to serve you better!</p>
	    <p class="custom-class1"> Explore our selection of fresh produce and pantry essentials.</p>
	    <div class="custom-class2">
		<h3>Discover Our Weekly Specials!</h3>
		<p>Visit us every week to find amazing deals on your favorite products.</p>
	    </div>
	</section>
    </main>

    <!-- Captures date and time of when the pages were last modified -->
    <?php
    $lastModified = filemtime(__FILE__);
    $formattedDate = date("F d, Y, H:i:s", $lastModified);
    ?>

    <footer>
	<!-- Logout Link -->
	<?php
	    if (isset($_SESSION['username'])) {
		echo '<li><a href="logout.php" style="margin-right: 20px;">Logout</a></li>';
	    }
	?>
	<!-- Establishes validation icons, copyright, and last modified date -->
	<p>&copy; <?php echo date('Y'); ?> Convenience-R-Us. All rights reserved.</p>
	<p>Last Modified: <?php echo $formattedDate; ?></p>
	<a href="valid-css.png" target="_blank"><img src="valid-css.png" alt="Valid CSS"></a>
	<a href="valid-xhtml1.png" target="_blank"><img src="valid-xhtml1.png" alt="Valid XHTML 1.0"></a>
    </footer>
</body>
</html>