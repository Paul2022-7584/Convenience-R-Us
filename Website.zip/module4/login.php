<?php
session_start();
include('db_connection.php');

// Handles form submission
if ($_SERVER['REQUEST_METHOD'] === 'POST') {
    $username = $_POST['username'];
    $password = $_POST['password'];

    // Sets usernames and passwords as an array with roles
    $validUsers = [
	'admin' => ['password' => 'admin', 'role' => 'admin'],
	'publisher' => ['password' => 'publisher', 'role' => 'publisher'],
	'customer' => ['password' => 'customer', 'role' => 'customer'],
    ];

    // Validates the username and password
    if (isset($validUsers[$username]) && $validUsers[$username]['password'] === $password) {
	// Sets session
	$_SESSION['username'] = $username;
	$_SESSION['role'] = $validUsers[$username]['role'];

	// Insert login data into database
	$accessLevel = $validUsers[$username]['role'];
	$insertQuery = "INSERT INTO users (username, password, access_level) VALUES ('$username', '$password', '$accessLevel')";
	mysqli_query($dbc, $insertQuery);

	// Redirects to appropriate page
	$redirectPage = isset($_POST['redirect_page']) ? $_POST['redirect_page'] : 'module4.php';
	header("Location: $redirectPage");
	exit();
    } else {
        $errorMessage = "Invalid username or password";
    }
}

// Check for the authentication status query parameter
$authSource = isset($_GET['source']) ? $_GET['source'] : '';
if ($authSource === 'module3' && !isset($_SESSION['username'])) {
    $errorMessage = "You must be authenticated as either Admin or Publisher to access.";
} elseif (!isset($_SESSION['username'])) {
    $errorMessage = "You must be authenticated to access.";
} else {
    // Redirects to appropriate page
    $redirectPage = isset($_POST['redirect_page']) ? $_POST['redirect_page'] : 'module4.php';
    header("Location: $redirectPage");
    exit();  
}
mysqli_close($dbc);
?>
<!DOCTYPE html PUBLIC "-//W3C//DTD XHTML 1.0 Strict//EN" "http://www.w3.org/TR/xhtml1/DTD/xhtml1-strict.dtd">
<html xmlns="http://www.w3.org/1999/xhtml">
<head>
    <!-- Meta information for search engines -->
    <meta http-equiv="Content-Type" content="text/html; charset=UTF-8" />
    <meta name="description" content="Sessions - Convenience-R-Us" />
    <meta name="keywords" content="Convenience-R-Us, employees, sessions" />
    <title>Sessions - Convenience-R-Us</title>
    <link rel="stylesheet" type="text/css" href="styles.css" />
</head>
<body>
    <header>
	<!-- Page header with the main title -->
	<h1>Login</h1>
    </header>

    <section>
	<!-- Display error message if login failed -->
	<?php if (isset($errorMessage)) : ?>
	    <p><?php echo $errorMessage; ?></p>
	<?php endif; ?>

	<!-- Login Form -->
	<form action="login.php" method="post">
	    <input type="hidden" name="redirect_page" value="<?php echo isset($_SERVER['HTTP_REFERER']) ? basename($_SERVER['HTTP_REFERER']) : 'module4.php'; ?>">

	    <label for="username">Username:</label>
	    <input type="text" name="username" required>
	    <br>

	    <label for="password">Password:</label>
	    <input type="password" name="password" required>
	    <br>

	    <input type="submit" value="Login">
	</form>
    </section>
	
    <nav>
	<ul>
	    <li><a href="index.php">Back to Home</a></li>
	</ul>
    </nav>

    <!-- Captures date and time of when the pages were last modified -->
    <?php
    $lastModified = filemtime(__FILE__);
    $formattedDate = date("F d, Y, H:i:s", $lastModified);
    ?>

    <footer>
	<!-- Establishes validation icons, copyright, and last modified date -->
	<p>&copy; <?php echo date('Y'); ?> Convenience-R-Us. All rights reserved.</p>
	<p>Last Modified: <?php echo $formattedDate; ?></p>
	<a href="valid-css.png" target="_blank"><img src="valid-css.png" alt="Valid CSS"></a>
	<a href="valid-xhtml1.png" target="_blank"><img src="valid-xhtml1.png" alt="Valid XHTML 1.0"></a>
    </footer>
</body>
</html>