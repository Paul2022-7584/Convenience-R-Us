<?php
session_start();

if ($_SERVER['REQUEST_METHOD'] === 'POST') {
    if (isset($_POST['confirm'])) {
        // Confirm button clicked, destroy the session
        session_destroy();

        $redirectPage = isset($_POST['redirect_page']) ? $_POST['redirect_page'] : 'login.php';
	header("Location: $redirectPage");
        exit();
    } elseif (isset($_POST['cancel'])) {

        header('Location: module4.php');
        exit();
    }
}
?>