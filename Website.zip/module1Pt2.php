<?php
// Includes variables for employees and database connection and session start
include 'variables.php';
include('db_connection.php');
session_start();

// Handles form submissions
if ($_SERVER["REQUEST_METHOD"] == "POST") {
   if (isset($_POST['delete_comment'])) {
       // Checks if the user is logged in and has the required role
       if (isset($_SESSION['role']) && $_SESSION['role'] === 'admin') {
	   $id = mysqli_real_escape_string($dbc, $_POST['id']);
	   $sql_delete = "DELETE FROM comments WHERE ID = $id";
	   if (mysqli_query($dbc, $sql_delete)) {
	       echo "Comment deleted successfully! ";
	   } else {
	       echo "Error deleting comment: " . mysqli_error($dbc);
	   }
       } else {
	   echo "You do not have the necessary permissions to delete comments.";
       }

    } elseif (isset($_POST['update_comment'])) {
	$id = mysqli_real_escape_string($dbc, $_POST['id']);
	$updatedComments = mysqli_real_escape_string($dbc, $_POST ['updated_comments']);
	$sql_update = "UPDATE comments SET updated_comments = '$updatedComments' WHERE ID = $id";
	if (mysqli_query($dbc, $sql_update)) {
	    echo "Comment updated successfully! ";
	} else {
	    echo "Error updating comment: " . mysqli_error($dbc);
	}

   } elseif (isset($_POST['submit_comment'])) {
       $name = mysqli_real_escape_string($dbc, $_POST['name']);
       $title = mysqli_real_escape_string($dbc, $_POST['title']);
       $comments = mysqli_real_escape_string($dbc, $_POST['comments']);

       $sql_insert = "INSERT INTO comments (name, title, comments) VALUES ('$name', '$title', '$comments')";
       if (mysqli_query($dbc, $sql_insert)) {
	   echo "Comment submitted successfully! ";
       } else {
	   echo "Error submitting comment: " . mysqli_error($dbc);
       }
        
   } 

}
// Displays comments
$sql_select = "SELECT * FROM comments ORDER BY commentdate DESC";
$result = mysqli_query($dbc, $sql_select);
?>
<!DOCTYPE html PUBLIC "-//W3C//DTD XHTML 1.0 Strict//EN" "http://www.w3.org/TR/xhtml1/DTD/xhtml1-strict.dtd">
<html xmlns="http://www.w3.org/1999/xhtml">
<head>
    <!-- Meta information for search engines -->
    <meta http-equiv="Content-Type" content="text/html; charset=UTF-8" />
    <meta name="description" content="Module 1: Week 1 Variables - Convenience-R-Us" />
    <meta name="keywords" content="Convenience-R-Us, employees, organizational chart" />
    <title>Module 1: Week 1 Variables - Convenience-R-Us</title>
    <link rel="stylesheet" type="text/css" href="styles.css" />
</head>
<body>
    <header>
	<!-- Page header with the main title -->
	<h1>Organizational Chart</h1>
    </header>

    <nav>
	<ul>
	    <li><a href="index.php">Back to Home</a></li>
	</ul>
    </nav>

    <main>
	<section class="content">
	    <h2>Our Team</h2>
	    <!-- Employee 1 -->
	    <h3><?php echo $employee1Name; ?></h3>
	    <img src="<?php echo $employee1Image; ?>" alt="<?php echo $employee1Name; ?>" />
	    <p><?php echo $employee1Info; ?></p>
	    <a href="<?php echo $employee1Link; ?>">Learn more about <?php echo $employee1Name; ?></a>
	
	    <!-- Employee 2 -->
	    <h3><?php echo $employee2Name; ?></h3>
	    <img src="<?php echo $employee2Image; ?>" alt="<?php echo $employee2Name; ?>" />
	    <p><?php echo $employee2Info; ?></p>
	    <a href="<?php echo $employee2Link; ?>">Learn more about <?php echo $employee2Name; ?></a>


	    <!-- Employee 3 -->
	    <h3><?php echo $employee3Name; ?></h3>
	    <img src="<?php echo $employee3Image; ?>" alt="<?php echo $employee3Name; ?>" />
	    <p><?php echo $employee3Info; ?></p>
	    <a href="<?php echo $employee3Link; ?>">Learn more about <?php echo $employee3Name; ?></a>
	</section>
    </main>

    <!-- Display form -->
    <form method="post" action="">
	<label for="name">Name:</label>
	<input type="text" name="name" required><br>
	<label for="title">Title:</label>
	<input type="text" name="title" required><br>
	<label for="comments">Comments:</label>
	<textarea name="comments" rows="4" required></textarea><br>
	<input type="submit" name="submit_comment" value="Submit">
    </form>

    <!-- Display comments -->
    <?php
    while ($row = mysqli_fetch_assoc($result)) {

	echo "<hr>";
	echo "<strong>Name:</strong> " . $row['name'] . "<br>";
	echo "<strong>Title:</strong> " . $row['title'] . "<br>";
	echo "<strong>Date:</strong> " . $row['commentdate'] . "<br>";

	if (!empty($row['updated_comments'])) {
             echo "<strong>Updated Comments:</strong> " . $row['updated_comments'] . "<br>";
	} elseif (!empty($row['comments'])) {
	    echo "<strong>Comments:</strong> " . $row['comments'] . "<br>";

	    // Form for updating comments
	    echo "<form method='post' action='module1Pt2.php'>";
	    echo "<input type='hidden' name='id' value='" . $row['ID'] . "'>";
	    echo "<label for='updated_comments'>Updated Comments:</label>";
	    echo "<textarea name='updated_comments' rows='4' required></textarea><br>";
	    echo "<input type='submit' name='update_comment' value='Update'>";
	    echo "</form>";
	}

	// Form for deleting comments
	echo "<form method='post' action='module1Pt2.php'>";
	echo "<input type='hidden' name='id' value='" . $row['ID'] . "'>";

	// Checks if the user is logged in and has the required role
	if (isset($_SESSION['role']) && $_SESSION['role'] === 'admin') {
	    echo "<input type='submit' name='delete_comment' value='Delete'>";
	} else {
	    echo "You do not have the necessary permissions to delete comments.";
	}
	echo "</form>";
	
    }
    ?>

    <!-- Captures date and time of when the pages were last modified -->
    <?php
    $lastModified = filemtime(__FILE__);
    $formattedDate = date("F d, Y, H:i:s", $lastModified);
    ?>

    <footer>
	<!-- Logout Link -->
	<?php
	    if (isset($_SESSION['username'])) {
		echo '<li><a href="logout.php" style="margin-right: 20px;">Logout</a></li>';
	    }
	?>
	<!-- Establishes validation icons, copyright, and last modified date -->
	<p>&copy; <?php echo date('Y'); ?> Convenience-R-Us. All rights reserved.</p>
	<p>Last Modified: <?php echo $formattedDate; ?></p>
	<a href="valid-css.png" target="_blank"><img src="valid-css.png" alt="Valid CSS"></a>
	<a href="valid-xhtml1.png" target="_blank"><img src="valid-xhtml1.png" alt="Valid XHTML 1.0"></a>
    </footer>
</body>
</html>