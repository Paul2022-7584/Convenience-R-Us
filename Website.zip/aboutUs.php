<?php
session_start();
?>

<!DOCTYPE html PUBLIC "-//W3C//DTD XHTML 1.0 Strict//EN" "http://www.w3.org/TR/xhtml1/DTD/xhtml1-strict.dtd">
<html xmlns="http://www.w3.org/1999/xhtml">
<head>
    <!-- Meta information for search engines -->
    <meta http-equiv="Content-Type" content="text/html; charset=UTF-8" />
    <meta name="description" content="About Convenience-R-Us - Your One-Stop Grocery Chain" />
    <meta name="keywords" content="Convenience-R-Us, about us, mission, groceries, history" />
    <title>About Us - Convenience-R-Us</title>
    <link rel="stylesheet" type="text/css" href="styles.css" />
</head>
<body>
    <header>
	<!-- Page header with the main title -->
	<h1>About Us</h1>
    </header>

    <nav>
	<!-- Navigation menu for internal links -->
	<ul>
	   <li><a href="module1.php">Return to Module 1</a></li>
	   <li><a href="module5.php">Return to Module 5</a></li>
	   <li><a href="contactUs.php">Contact Us</a></li>
	   <li><a href="phpinfo.php">PHP Configuration</a></li>
           <li><a href="index.php">Return to Home</a></li>
	</ul>
    </nav>

    <main>
	<!-- Main content section for the company info -->
	<section class="content">
	    <h2>Our Story</h2>
	    <p>Convenience-R-Us has been serving communities for over 20 years. Learn about our journey and commitment to providing quality products and exceptional service.</p>

	    <h2>Company Overview</h2>
	    <?php
		echo "<p>Convenience-R-Us is a fictional grocery store chain dedicated to providing customers with the best in groceries and household essentials. Our mission is to make shopping convenient and enjoyable for all. We offer a wide range of fresh produce, pantry staples, and household items, ensuring that your shopping needs are met under one roof.</p>";
		echo "<p>Founded on the principles of quality, affordability, and excellent customer service, Convenience-R-Us has become a trusted name in the industry. We are committed to delivering value to our customers and supporting the communities we serve. Thank you for choosing Convenience-R-Us as your one-stop grocery store.</p>";
	    ?>
	    <h2>Spiritual Mission</h2>
	    <?php
	    	echo "<p>The Lord watches over us each and every day of our lives. And through the guiding light of Christ, Convenience-R-Us is committed to upholding the virtues of faith, trust, and honestly. We believe that by aligning our actions with these divine principles, we can create a community where righteousness prevails. As stated in Psalm 133:1, by standing for what we believe in, we as brothers and sisters can dwell in unity and strive for a community linked in hearts and souls.</p>";
		echo "<p>Each day, we strive to emulate the teachings of Christ by serving others with unwavering devotion in our hearts and divine wisdom in our minds. At Convenience-R-Us, our mission is to go above and beyond, embodying love and devotion in all that we do. With God as our anchor, we navigate the path of service, ensuring that His presence is felt in every interaction and that His love is the driving force behind our endeavors. Together we serve, and together we stand as a strengthened community. </p>";
	     ?>
	</section>
    </main>
	
    <!-- Captures date and time of when the pages were last modified -->
    <?php
    $lastModified = filemtime(__FILE__);
    $formattedDate = date("F d, Y, H:i:s", $lastModified);
    ?>

    <footer>
	<!-- Logout Link -->
	<?php
	    if (isset($_SESSION['username'])) {
		echo '<li><a href="logout.php" style="margin-right: 20px;">Logout</a></li>';
	    }
	?>
	<div class="partnership-display">
	    <p>Partnership with:</p>
	    <img src="logo.png" alt="Publix Logo">
	    <p>Convenience-R-Us x Publix</p>
	</div>
	<!-- Establishes validation icons, copyright, and last modified date -->
	<p>Check us out on our social media pages!</p>
	<a href="instagramIcon.png" target="_blank"><img src="instagramIcon.png" alt="Instagram Icon"></a>
	<a href="twitterIcon.png" target="_blank"><img src="twitterIcon.png" alt="Twitter Icon"></a>
	<p>&copy; <?php echo date('Y'); ?> Convenience-R-Us. All rights reserved.</p>
	<p>Last Modified: <?php echo $formattedDate; ?></p>
	<a href="valid-css.png" target="_blank"><img src="valid-css.png" alt="Valid CSS"></a>
	<a href="valid-xhtml1.png" target="_blank"><img src="valid-xhtml1.png" alt="Valid XHTML 1.0"></a>
    </footer>
</body>
</html>