<!DOCTYPE html PUBLIC "-//W3C//DTD XHTML 1.0 Strict//EN" "http://www.w3.org/TR/xhtml1/DTD/xhtml1-strict.dtd">
<html xmlns="http://www.w3.org/1999/xhtml">
<head>
    <!-- Meta information for search engines -->
    <meta http-equiv="Content-Type" content="text/html; charset=UTF-8" />
    <meta name="description" content="Module 1: Week 1 Variables - Convenience-R-Us" />
    <meta name="keywords" content="Convenience-R-Us, groceries, food" />
    <title>Module 1: Week 1 Variables - Convenience-R-Us</title>
    <link rel="stylesheet" type="text/css" href="styles.css" />
</head>
<body>

    <?php
    // Employee 1
    $employee1Name = "George Patterson";
    $employee1Image = "george.jpg";
    $employee1Info = "George Patterson is the CEO of Convenience-R-Us. He has over 20 years of experience in the grocery industry.";
    $employee1JobTitle = "CEO";
    $employee1Department = "Executive Management";
    $employee1Degree = "MBA";
    $employee1Hobby = "Golf";
    $employee1Goals = "To expand the business nationwide";
    $employee1Interests = "Business strategy, leadership";

    // Employee 2
    $employee2Name = "James Anderson";
    $employee2Image = "james.jpg";
    $employee2Info = "James Anderson is the Chief Operating Officer. He oversees daily operations and ensures smooth store functioning.";
    $employee2JobTitle = "COO";
    $employee2Department = "Operations";
    $employee2Degree = "BSc in Business Administration";
    $employee2Hobby = "Painting";
    $employee2Goals = "Efficient store management";
    $employee2Interests = "Operational efficiency, team collaboration";   

    // Employee 3
    $employee3Name = "Steven Johnson";
    $employee3Image = "steven.jpg";
    $employee3Info = "Steven Johnson is the Head of Marketing. He leads marketing campaigns and promotions to attract customers.";
    $employee3JobTitle = "Head of Marketing";
    $employee3Department = "Marketing";
    $employee3Degree = "Marketing and Advertising";
    $employee3Hobby = "Photography";
    $employee3Goals = "Increase customer engagement";
    $employee3Interests = "Marketing trends, consumer behavior";

    // Links to each employee's page
    $employee1Link = "george.php";
    $employee2Link = "james.php";
    $employee3Link = "steven.php";
    ?>

</body>
</html>