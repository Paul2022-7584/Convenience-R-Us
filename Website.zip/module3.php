<?php
session_start();

if (!isset($_SESSION['username']) || ($_SESSION['role'] !== 'admin' && $_SESSION['role'] !== 'publisher')) {
    header("Location: login.php?source=module3");
    exit();
}
?>

<?php
    
    $organizationalChart = array(
	'person1' => array(
	    'name' => 'George Patterson',
	    'job' => 'CEO',
	    'department' => 'Executive Management',
	    'interests' => 'Business strategy, leadership',
	),
	'person2' => array(
	    'name' => 'James Anderson',
	    'job' => 'COO',
	    'department' => 'Operations',
	    'interests' => 'Operational efficiency, team collaboration',
	),
	'person3' => array(
	    'name' => 'Steven Johnson',
	    'job' => 'Head of Marketing',
	    'department' => 'Marketing',
	    'interests' => 'Marketing trends, consumer behavior',
	),
);

   // Function to update individual's data
   function updatePersonData($personId, $job, $department, $interests) {
   global $organizationalChart;

    // Updates the data, and sends it to the updated_info.php page
    $organizationalChart[$personId]['job'] = $job;
    $organizationalChart[$personId]['department'] = $department;
    $organizationalChart[$personId]['interests'] = $interests;

    $personName = $organizationalChart[$personId]['name'];

    header("Location: updated_info.php?person=$personId&name=$personName&job=$job&department=$department&interests=$interests");
    exit();
}

    // Handles form submission
    if ($_SERVER['REQUEST_METHOD'] === 'POST') {
        $selectedPerson = $_POST['person'];
        $newJob = $_POST['new_job'];
        $newDepartment = $_POST['new_department'];
        $newInterests = $_POST['new_interests'];

   // Validate form data
   if (array_key_exists($selectedPerson, $organizationalChart)) {
     // Update individual's data
     updatePersonData($selectedPerson, $newJob, $newDepartment, $newInterests);
  } else {
      echo "<p>Invalid selection. Please choose a person from the dropdown.</p>";
  }
 }
?>




<!DOCTYPE html PUBLIC "-//W3C//DTD XHTML 1.0 Strict//EN" "http://www.w3.org/TR/xhtml1/DTD/xhtml1-strict.dtd">
<html xmlns="http://www.w3.org/1999/xhtml">
<head>
    <!-- Meta information for search engines -->
    <meta http-equiv="Content-Type" content="text/html; charset=UTF-8" />
    <meta name="description" content="Module 3: Week 3 Arrays - Convenience-R-Us" />
    <meta name="keywords" content="Convenience-R-Us, employees, arrays" />
    <title>Module 3: Week 3 Arrays - Convenience-R-Us</title>
    <link rel="stylesheet" type="text/css" href="styles.css" />
</head>
<body>
    <header>
	<!-- Page header with the main title -->
	<h1>Arrays</h1>
	<form action="" method="post">
    </header>
    <nav>
	<ul>
	    <li><a href="index.php">Back to Home</a></li>
	</ul>
    </nav>

	<label for="person">Select a person:</label>
	<select name ="person" id="person" required>
	    <?php

	    // Populate the dropdown with person names
	    foreach ($organizationalChart as $personId => $personData) {
	        echo "<option value=\"$personId\">{$personData['name']}</option>";
	    }
	    ?>
        </select>
	<br>

	<!-- Input options for the user -->
	<label for="new_job">New Job:</label>
	<input type="text" name="new_job" required>
	<br>

	<label for="new_department">New Department:</label>
	<input type="text" name="new_department" required>
	<br>

	<label for="new_interests">New Interests:</label>
	<input type="text" name="new_interests" required>
	<br>

	<input type="submit" value="Update Information">
    </form>
    



    <!-- Captures date and time of when the pages were last modified -->
    <?php
    $lastModified = filemtime(__FILE__);
    $formattedDate = date("F d, Y, H:i:s", $lastModified);
    ?>

    <footer>
	<!-- Sets up logout link when logged in -->
	<?php
	    if (isset($_SESSION['username'])) {
		echo '<li><a href="logout.php" style="margin-right: 20px;">Logout</a></li>';
	    }
	?>
	<!-- Establishes validation icons, copyright, and last modified date -->
	<p>&copy; <?php echo date('Y'); ?> Convenience-R-Us. All rights reserved.</p>
	<p>Last Modified: <?php echo $formattedDate; ?></p>
	<a href="valid-css.png" target="_blank"><img src="valid-css.png" alt="Valid CSS"></a>
	<a href="valid-xhtml1.png" target="_blank"><img src="valid-xhtml1.png" alt="Valid XHTML 1.0"></a>
    </footer>
</body>
</html>