<?php
// Connects to database
$dbc = mysqli_connect('localhost', 'paul_admin', 'adminp@ssword', 'Paul_Farri');
if (!$dbc) {
   echo "Error: Unable to connect to database:" . mysqli_connect_error(); 
}

echo "Connected to the database successfully! ";
?>