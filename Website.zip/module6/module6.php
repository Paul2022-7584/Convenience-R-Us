<?php
session_start();
?>

<!DOCTYPE html PUBLIC "-//W3C//DTD XHTML 1.0 Strict//EN" "http://www.w3.org/TR/xhtml1/DTD/xhtml1-strict.dtd">
<html xmlns="http://www.w3.org/1999/xhtml">
<head>
    <!-- Meta information for search engines -->
    <meta http-equiv="Content-Type" content="text/html; charset=UTF-8" />
    <meta name="description" content="Module 6: Week 6 Databases - Convenience-R-Us" />
    <meta name="keywords" content="Convenience-R-Us, employees, databases" />
    <title>Module 6: Week 6 Databases - Convenience-R-Us</title>
    <link rel="stylesheet" type="text/css" href="styles.css" />
</head>
<body>
    <header>
	<!-- Page header with the main title -->
	<h1>Databases</h1>
    </header>

    <nav>
	<ul>
	    <li><a href="index.php">Back to Home</a></li>
	    <li><a href="module1Pt2.php">Organizational Chart</a></li>
	</ul>
    </nav>

    <style>
	nav ul li:not(:last-child) {
	    margin-bottom: 10px;
	}
    </style>

    <!-- Captures date and time of when the pages were last modified -->
    <?php
    $lastModified = filemtime(__FILE__);
    $formattedDate = date("F d, Y, H:i:s", $lastModified);
    ?>

    <footer>
	<!-- Sets up logout link when logged in -->
	<?php
	    if (isset($_SESSION['username'])) {
		echo '<li><a href="logout.php" style="margin-right: 20px;">Logout</a></li>';
	    }
	?>
	<!-- Establishes validation icons, copyright, and last modified date -->
	<p>&copy; <?php echo date('Y'); ?> Convenience-R-Us. All rights reserved.</p>
	<p>Last Modified: <?php echo $formattedDate; ?></p>
	<a href="valid-css.png" target="_blank"><img src="valid-css.png" alt="Valid CSS"></a>
	<a href="valid-xhtml1.png" target="_blank"><img src="valid-xhtml1.png" alt="Valid XHTML 1.0"></a>
    </footer>
</body>
</html>