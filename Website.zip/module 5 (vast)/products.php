<?php
// Starts session
session_start();
include 'db_connection.php';
include('Header.php');

?>

<nav>
   <ul>
      <a href="index.php">Back to Home</a>
      <a href="module5.php">Back to Module 5</a>
      <a href="contactUs.php">Contact Us</a>
   </ul>
</nav>

<?php
// Array of products with details
$products = [
    [
	'id' => 1,
	'name' => 'Cereal',
	'image' => 'cereal.jfif',
	'description' => "Stay refreshed each morning with Convenience-R-Us's nutritious cereal!",
	'price' => 9.99
    ],

    [
	'id' => 2,
	'name' => 'Dog Treats',
	'image' => 'dogTreats.jpg',
	'description' => "Keep your pet happy and healthy with Convenience-R-Us's quality brand dog treats!",
	'price' => 9.99
    ],

    [

        'id' => 3,
	'name' => 'Fish',
	'image' => 'fish.jpg',
	'description' => "Convenience-R-Us's fish, including but not limited to salmon, catfish, trout, and bass, are all freshly caught without the addition of any additive chemicals!",
	'price' => 7.99
    ],

    [

	'id' => 4,
	'name' => 'Pears',
	'image' => 'pears.jpg',
	'description' => "Give yourself a healthy boost of fruit each day with Convenience-R-Us's naturally grown pears!",
	'price' => 4.99
    ],

    [

        'id' => 5,
	'name' => 'Potting Soil',
	'image' => 'pottingSoil.jpg',
	'description' => "With Convenience-R-Us's high quality potting soil, your plants will always come out beautifully grown!",
	'price' => 24.99
    ],

    [

        'id' => 6,
	'name' => 'Pringles',
	'image' => 'pringles.jpg',
	'description' => "Convenience-R-Us's pringles chips always puts a smile on the face of every child and adult, now in additional flavors!",
	'price' => 5.99
    ],


    [

        'id' => 7,
	'name' => 'Ranch Dressing',
	'image' => 'ranchDressing.jpg',
	'description' => "Convenience-R-Us's ranch dressing offers a creamy and savory flavor to elevate anybody's salads and snacks!",
	'price' => 9.99
    ],


    [

        'id' => 8,
	'name' => 'Sink Cleaner',
	'image' => 'sinkCleaner.jpeg',
	'description' => "With Convenience-R-Us's high grade sink cleaner, you can finally say goodbye to even the toughest of stains and gunk on your sinks!",
	'price' => 7.99
    ],


    [

        'id' => 9,
	'name' => 'Steaks',
	'image' => 'steaks.jpg',
	'description' => "Convenience-R-Us's high quality cuts of steaks ensure a delicious and savory dining experience right from the comfort of your own home at only a fraction of the price!",
	'price' => 19.99
    ],


    [

        'id' => 10,
	'name' => 'Tomatos',
	'image' => 'tomatos.jfif',
	'description' => "Whether you wish to make a pizza or pasta sauce, or simply want to have a fresh salad with your meal, Convenience-R-Us's freshly grown tomatos are perfect for enhancing your dish variety with vibrant taste!",
	'price' => 9.99
    ]
];
   
// Displays products with their image, description, price, and cart inputs
foreach ($products as $product) {
  echo "<div>";
  echo "<img src='{$product['image']}' alt='{$product['name']} image'><br>";
  echo "<p>{$product['description']}</p>";
  echo "<p>Price: $" . number_format($product['price'], 2) . "</p>";
  echo "<form action='cart.php' method='post'>";
  echo "<input type='hidden' name='product_id' value='{$product['id']}'>";
  echo "<input type='submit' name='add_to_cart' value='Add to Cart'>";
  echo "</form>";
  echo "</div>";
}
mysqli_close($dbc);
include('Footer.php');
?>