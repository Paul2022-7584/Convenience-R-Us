<?php
session_start();
include 'db_connection.php';
include('Header.php');

// Array of products
$products = [
    1 => [
	'name' => 'Cereal',
	'price' => 9.99,
    ],

    2 => [
	'name' => 'Dog Treats',
	'price' => 9.99,
    ],

    3 => [
	'name' => 'Fish',
	'price' => 7.99,
    ],

    4 => [
	'name' => 'Pears',
	'price' => 4.99,
    ],

    5 => [
	'name' => 'Potting Soil',
	'price' => 24.99,
    ],

    6 => [
	'name' => 'Pringles',
	'price' => 5.99,
    ],


    7 => [
	'name' => 'Ranch Dressing',
	'price' => 9.99,
    ],


    8 => [
	'name' => 'Sink Cleaner',
	'price' => 7.99,
    ],


    9 => [
	'name' => 'Steaks',
	'price' => 19.99,
    ],


    10 => [
	'name' => 'Tomatos',
	'price' => 9.99,
    ]
];

// Checks if 'Add to Cart' form is submitted and if product is already in the cart
if (isset($_POST['add_to_cart'])) {
    $product_id = $_POST['product_id'];
    if (!isset($_SESSION['cart'][$product_id])) {
	$_SESSION['cart'][$product_id] = 1;
    } else {
	$_SESSION['cart'][$product_id]++;
    }
}


// Displays the cart contents
if (empty($_SESSION['cart'])) {
    echo "<p>Your cart is empty.</p>";
} else {
    echo "<ul>";
    foreach ($_SESSION['cart'] as $product_id => $quantity) {
	// Fetch product details
	$product = $products[$product_id];
	echo "<li>Product ID: $product_id, Product Name: {$product['name']}, Quantity: $quantity</li>";
    }
    echo "</ul>";
    
    // Form to remove items from the cart
    echo "<form action='cart.php' method='post'>";
    foreach ($_SESSION['cart'] as $product_id => $quantity) {
	$product = $products[$product_id];
	echo "<input type='checkbox' name='remove_from_cart[]' value='$product_id'> Remove {$product['name']}<br>";

    }
    // Submit button to remove selected items
    echo "<input type='submit' name='remove' value='Remove Selected'>";
    echo "</form>";

}

echo '<a href="checkout.php">Proceed to Checkout</a>';
echo '<br>';
echo '<a href="products.php">Continue Shopping</a>';

mysqli_close($dbc);
include('Footer.php');

// Checks if items should be removed from the cart
if (isset($_POST['remove_from_cart'])) {
    $remove_ids = $_POST['remove_from_cart'];
    foreach ($remove_ids as $remove_id) {
        if (isset($_SESSION['cart'][$remove_id])) {
	    unset($_SESSION['cart'][$remove_id]);
	}
    }
}
?>