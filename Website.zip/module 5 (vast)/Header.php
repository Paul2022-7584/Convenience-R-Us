<!DOCTYPE html PUBLIC "-//W3C//DTD XHTML 1.0 Strict//EN" "http://www.w3.org/TR/xhtml1/DTD/xhtml1-strict.dtd">
<html xmlns="http://www.w3.org/1999/xhtml">
<head>
    <!-- Meta information for search engines -->
    <meta http-equiv="Content-Type" content="text/html; charset=UTF-8" />
    <meta name="description" content="Module 5: Week 5 Sessions Project - Convenience-R-Us" />
    <meta name="keywords" content="Convenience-R-Us, employees, products, sessions" />
    <meta name="author" content="Convenience-R-Us">
    <title>Module 5: Week 5 Sessions Project - Convenience-R-Us</title>
    <link rel="stylesheet" type="text/css" href="styles.css" />
</head>
<body>
    <header>
	<!-- Page header with the main title -->
	<h1>CMS Sessions Project</h1>
    </header>