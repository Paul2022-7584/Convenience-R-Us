    <nav>
	<!-- Navigation menu for internal links -->
	<ul>
	    <li><a href="index.php">Back to Home</a></li>
	    <li><a href="aboutUs.php">About Us</a></li>
	    <li><a href="login.php">To Log-In</a></li>
	    <li><a href="module5.php?go_to_products=true">Go to Products in Stock</a></li>
	    <li><a href="contactUs.php">Contact Us</a><li>
	</ul>
    </nav>