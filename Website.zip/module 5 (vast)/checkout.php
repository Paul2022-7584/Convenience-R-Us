<?php
session_start();
include 'db_connection.php';
include('Header.php');

$products = [
    1 => [
	'name' => 'Cereal',
	'price' => 9.99,
    ],

    2 => [
	'name' => 'Dog Treats',
	'price' => 9.99,
    ],

    3 => [
	'name' => 'Fish',
	'price' => 7.99,
    ],

    4 => [
	'name' => 'Pears',
	'price' => 4.99,
    ],

    5 => [
	'name' => 'Potting Soil',
	'price' => 24.99,
    ],

    6 => [
	'name' => 'Pringles',
	'price' => 5.99,
    ],


    7 => [
	'name' => 'Ranch Dressing',
	'price' => 9.99,
    ],


    8 => [
	'name' => 'Sink Cleaner',
	'price' => 7.99,
    ],


    9 => [
	'name' => 'Steaks',
	'price' => 19.99,
    ],


    10 => [
	'name' => 'Tomatos',
	'price' => 9.99,
    ]
];

if (empty($_SESSION['cart'])) {
    header("Location: products.php");
    exit();
}

$taxRate = 0.08;
$totalPrice = 0;

// Display Order summary and calculates the totals
foreach ($_SESSION['cart'] as $product_id => $quantity) {
    // Checks if the product_id exists in the products array
    if (isset($products[$product_id])) {
        // Fetch product details
    	$product = $products[$product_id];
        $totalPrice += $product['price'] * $quantity;
	
	echo "<li>Product: {$product['name']}, Quantity: $quantity</li>";
    }
}

$tax = $totalPrice * $taxRate;
$finalTotal = $totalPrice + $tax;


// Inserts each item in the cart into the shopping_cart table
foreach ($_SESSION['cart'] as $product_id => $quantity) {
    if (isset($products[$product_id])) {
	$product = $products[$product_id];
	$productName = mysqli_real_escape_string($dbc, $product['name']);
	$price = $product['price'];
	$total = $price * $quantity;

	$insertQuery = "INSERT INTO shopping_cart (product_name, price, quantity, total) VALUES ('$productName', '$price', '$quantity', '$total')";
	mysqli_query($dbc, $insertQuery);
    }
}
?>

<p>Total Price: $<?php echo number_format($totalPrice, 2); ?></p>
<p>Tax (<?php echo ($taxRate * 100); ?>%): $<?php echo number_format($tax, 2); ?></p>
<p>Final Total: $<?php echo number_format($finalTotal, 2); ?></p>

<form action="module5.php" method="post">
    <input type="submit" name="back_to_module5" value="Back to Module 5">
</form>

<form action="index.php" method="post">
    <input type="submit" name="back_to_index" value="Back to Home">
</form>

<?php
include('Footer.php');
mysqli_close($dbc);
?>