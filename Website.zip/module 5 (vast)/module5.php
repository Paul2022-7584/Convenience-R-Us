<?php
session_start();
include('Header.php');

// Checks if the user clicked on the products page link and sees if the user is logged in
if (isset($_GET['go_to_products']) && $_GET['go_to_products'] === 'true') {
    if (!isset($_SESSION['username'])) {
        echo "<p>You must log in to access the products.</p>";
        echo "<p>Redirecting to login page...</p>";
        header("refresh:3;url=login.php");
        include('Footer.php');
        exit();
    } else {
	header("Location: products.php");
	exit();
    }
}

include('Menu.php');
include('Footer.php');
?>