<!DOCTYPE html PUBLIC "-//W3C//DTD XHTML 1.0 Strict//EN" "http://www.w3.org/TR/xhtml1/DTD/xhtml1-strict.dtd">
<html xmlns="http://www.w3.org/1999/xhtml">
<head>
    <!-- Meta information for search engines -->
    <meta http-equiv="Content-Type" content="text/html; charset=UTF-8" />
    <meta name="description" content="Module 3: Week 3 Arrays - Convenience-R-Us" />
    <meta name="keywords" content="Convenience-R-Us, employees, arrays" />
    <title>Module 3: Updated Info - Convenience-R-Us</title>
    <link rel="stylesheet" type="text/css" href="styles.css" />
</head>
<body>
    <header>
        <h1>Module 3: Updated Info</h1>
    </header>

<?php
include 'variables.php';
    
    // Retrieves data from the query parameters
    $personId = $_GET['person'];
    $personName = $_GET['name'];
    $job = $_GET['job'];
    $department = $_GET['department'];
    $interests = $_GET['interests'];


    // Displays updated info
    echo "<h2>Updated Information for $personName:</h2>";
    echo "<p>Job: $job</p>";
    echo "<p>Department: $department</p>";
    echo "<p>Interests: $interests</p>";
?>
    <!-- Gives the option of returing home -->
    <li><a href="index.php">Back to Home</a></li>


    <!-- Captures date and time of when the pages were last modified -->
    <?php
    $lastModified = filemtime(__FILE__);
    $formattedDate = date("F d, Y, H:i:s", $lastModified);
    ?>

<style>
    body {
	font-family: 'Arial', sans-serif;
	background-color: #f4f4f4;
	color; #333;
	margin: 20px;
   }

   header {
	background-color: #3498db;
	padding: 10px;
	text-align: center;
	color: #fff;
   }

   section {
	max-width: 600px;
	margin: 20px auto;
	padding: 20px;
	background-color: #fff;
	border-radius: 8px;
	box-shadow: 0 0 10px rgba(0, 0, 0, 0.1);
   }

   h2  {
	color: #3498db;
   }

   p {
	margin-bottom: 10px;
   }

</style>


    <footer>
	<!-- Establishes validation icons, copyright, and last modified date -->
	<p>&copy; <?php echo date('Y'); ?> Convenience-R-Us. All rights reserved.</p>
	<p>Last Modified: <?php echo $formattedDate; ?></p>
	<a href="valid-css.png" target="_blank"><img src="valid-css.png" alt="Valid CSS"></a>
	<a href="valid-xhtml1.png" target="_blank"><img src="valid-xhtml1.png" alt="Valid XHTML 1.0"></a>
    </footer>
</body>
</html>