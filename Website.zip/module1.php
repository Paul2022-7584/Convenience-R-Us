<?php
session_start();
?>


<!DOCTYPE html PUBLIC "-//W3C//DTD XHTML 1.0 Strict//EN" "http://www.w3.org/TR/xhtml1/DTD/xhtml1-strict.dtd">
<html xmlns="http://www.w3.org/1999/xhtml">
<head>
    <!-- Meta information for search engines -->
    <meta http-equiv="Content-Type" content="text/html; charset=UTF-8" />
    <meta name="description" content="Module 1: Week 1 Foundations - Convenience-R-Us" />
    <meta name="keywords" content="Convenience-R-Us, module 1, week 1, groceries, food" />
    <title>Module 1: Week 1 Foundations - Convenience-R-Us</title>
    <link rel="stylesheet" type="text/css" href="styles.css" />
</head>
<body>
    <header>
	<!-- Page header with the main title -->
	<h1>Module 1: Week 1 Foundations</h1>
    </header>

    <main>
	<section class="content">
	    <h2>Resources for Module 1</h2>
	    <ul>
		<!-- Navigation menu for internal links -->
	        <li><a href="aboutUs.php">About Us</a></li>
		<li><a href="contactUs.php">Contact Us</a><li>
		<li><a href="phpinfo.php">PHP Configuration</a><li>
		<li><a href="index.php">Return to Home</a></li>
	    </ul>
	</section>
    </main>
    <!-- Captures date and time of when the pages were last modified -->
    <?php
    $lastModified = filemtime(__FILE__);
    $formattedDate = date("F d, Y, H:i:s", $lastModified);
    ?>

    <footer>
	<!-- Sets up logout link when logged in -->
	<?php
	    if (isset($_SESSION['username'])) {
		echo '<li><a href="logout.php" style="margin-right: 20px;">Logout</a></li>';
	    }
	?>
	<!-- Establishes validation icons, copyright, and last modified date -->
	<p>&copy; <?php echo date('Y'); ?> Convenience-R-Us. All rights reserved.</p>
	<p>Last Modified: <?php echo $formattedDate; ?></p>
	<a href="valid-css.png" target="_blank"><img src="valid-css.png" alt="Valid CSS"></a>
	<a href="valid-xhtml1.png" target="_blank"><img src="valid-xhtml1.png" alt="Valid XHTML 1.0"></a>
    </footer>
</body>
</html>