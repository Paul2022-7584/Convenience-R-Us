<!DOCTYPE html PUBLIC "-//W3C//DTD XHTML 1.0 Strict//EN" "http://www.w3.org/TR/xhtml1/DTD/xhtml1-strict.dtd">
<html xmlns="http://www.w3.org/1999/xhtml">
<head>
    <!-- Meta information for search engines -->
    <meta http-equiv="Content-Type" content="text/html; charset=UTF-8" />
    <meta name="description" content="Product GET Request" />
    <meta name="keywords" content="product ranking, poll, GET method" />
    <title>Processing GET Request</title>
</head>
<body>
    <h1>Processing GET Request</h1>

    <!-- Stores user's name and shows the results of the GET poll -->
    <?php
    if ($_SERVER['REQUEST_METHOD'] === 'GET') {
	$name = $_GET['name'];
	$comments = $_GET['comments'];

	echo "<h2>Thank you, $name, for participating in the poll!</h2>";
	echo "<p>Your comments: $comments</p>";

	echo "<h2>Product Rankings:</h2>";
	echo "<ul>";
	for ($i = 1; $i <= 3; $i++) {
	    $product_rank = $_GET["product{$i}_rank"];
	    echo "<li>Product $i Ranking: $product_rank</li>";
	}
	echo "</ul>";
    } else {
	echo "<p>Invalid request method.</p>";
    }
    ?>

    <!-- Captures date and time of when the pages were last modified -->
    <?php
    $lastModified = filemtime(__FILE__);
    $formattedDate = date("F d, Y, H:i:s", $lastModified);
    ?>
    <li><a href="index.php">Return to Home</a></li>

    <footer>
	<!-- Establishes validation icons, copyright, and last modified date -->
	<p>&copy; <?php echo date('Y'); ?> Convenience-R-Us. All rights reserved.</p>
	<p>Last Modified: <?php echo $formattedDate; ?></p>
	<a href="valid-css.png" target="_blank"><img src="valid-css.png" alt="Valid CSS"></a>
	<a href="valid-xhtml1.png" target="_blank"><img src="valid-xhtml1.png" alt="Valid XHTML 1.0"></a>
    </footer>
</body>
</html>