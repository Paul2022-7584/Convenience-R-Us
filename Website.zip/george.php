<?php
//Include variables from variables.php
include 'variables.php';

// Start the session
session_start();

// Check if the user is authenticated
if (!isset($_SESSION['username']) || $_SESSION['username'] !== 'customer') {

// Redirects to the login page if not authenticated
    header('Location: login.php?auth=false'); 
    exit();
}
?>
<!DOCTYPE html PUBLIC "-//W3C//DTD XHTML 1.0 Strict//EN" "http://www.w3.org/TR/xhtml1/DTD/xhtml1-strict.dtd">
<html xmlns="http://www.w3.org/1999/xhtml">
<head>
    <!-- Meta information for search engines -->
    <meta http-equiv="Content-Type" content="text/html; charset=UTF-8" />
    <meta name="description" content="<?php echo $employee1Name; ?>" />
    <meta name="keywords" content="<?php echo $employee1Name; ?>" />
    <title><?php echo $employee1Name; ?></title>
    <link rel="stylesheet" type="text/css" href="styles.css" />
</head>
<body>
   <header>
       <!-- Employee Name -->
       <h1><?php echo $employee1Name; ?></h1>
   </header>


   <main>
       <section class="content">
	   <!-- Display individuals's information using variables -->
	   <h2>Meet <?php echo $employee1Name; ?></h2>
	   <img src="<?php echo $employee1Image; ?>" alt="<?php echo $employee1Name; ?>" />
	   <p><?php echo $employee1Info; ?></p>
	   <p><strong>Job Title:</strong> <?php echo $employee1JobTitle; ?></p>
	   <p><strong>Department:</strong> <?php echo $employee1Department; ?></p>
	   <p><strong>Degree:</strong> <?php echo $employee1Degree; ?></p>
	   <p><strong>Hobby:</strong> <?php echo $employee1Hobby; ?></p>
	   <p><strong>Goals:</strong> <?php echo $employee1Goals; ?></p>
	   <p><strong>Interests:</strong> <?php echo $employee1Interests; ?></p>
       </section>
   </main>


    <!-- Captures date and time of when the pages were last modified -->
    <?php
    $lastModified = filemtime(__FILE__);
    $formattedDate = date("F d, Y, H:i:s", $lastModified);
    ?>

    <footer>
	<!-- Logout Link -->
	<?php
	    if (isset($_SESSION['username'])) {
		echo '<li><a href="logout.php" style="margin-right: 20px;">Logout</a></li>';
	    }
	?>
	<a href="module1Pt2.php">Back to Organizational Chart</a>
	<!-- Establishes validation icons, copyright, and last modified date -->
	<p>&copy; <?php echo date('Y'); ?> Convenience-R-Us. All rights reserved.</p>
	<p>Last Modified: <?php echo $formattedDate; ?></p>
	<a href="valid-css.png" target="_blank"><img src="valid-css.png" alt="Valid CSS"></a>
	<a href="valid-xhtml1.png" target="_blank"><img src="valid-xhtml1.png" alt="Valid XHTML 1.0"></a>
    </footer>
</body>
</html>