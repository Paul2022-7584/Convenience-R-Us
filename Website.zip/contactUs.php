<?php
session_start();
?>

<!DOCTYPE html PUBLIC "-//W3C//DTD XHTML 1.0 Strict//EN" "http://www.w3.org/TR/xhtml1/DTD/xhtml1-strict.dtd">
<html xmlns="http://www.w3.org/1999/xhtml">
<head>
    <!-- Meta information for search engines -->
    <meta http-equiv="Content-Type" content="text/html; charset=UTF-8" />
    <meta name="description" content="Contact Us - Convenience-R-Us" />
    <meta name="keywords" content="Convenience-R-Us, contact us, email, phone, address" />
    <title>Contact Us - Convenience-R-Us</title>
    <link rel="stylesheet" type="text/css" href="styles.css" />
</head>
<body>
    <header>
	<!-- Page header with the main title -->
	<h1>Contact Us</h1>
    </header>

    <nav>
	<!-- Navigation menu for internal links -->
	<ul>
	   <li><a href="module1.php">Return to Module 1</a></li>
	   <li><a href="module5.php">Return to Module 5</a></li>
	   <li><a href="aboutUs.php">About Us</a></li>
	   <li><a href="phpinfo.php">PHP Configuration</a></li>
           <li><a href="index.php">Return to Home</a></li>
	</ul>
    </nav>	

    <main>
	<!-- Main content section for contact info -->
	<section class="content">
	    <h2>Contact Information</h2>
	    <p>If you have any questions or need assistence, please feel free to reach out to us using the following contact details:</p>
	    <ul>
		<li>Email: <a href="mailto:contact@convenience-r-us.com"><?php print 'contact@convenience-r-us.com'; ?></a></li>
		<li>Phone: <?php print '+1 (123) 456-7890'; ?></li>	    
		<li>Address: <?php print '123 Main Street, Baltimore, MD 12345'; ?></li>
	    </ul>
	</section>
    </main>

    <!-- Captures date and time of when the pages were last modified -->
    <?php
    $lastModified = filemtime(__FILE__);
    $formattedDate = date("F d, Y, H:i:s", $lastModified);
    ?>

    <footer>
	<!-- Logout Link -->
	<?php
	    if (isset($_SESSION['username'])) {
		echo '<li><a href="logout.php" style="margin-right: 20px;">Logout</a></li>';
	    }
	?>
	<!-- Establishes validation icons, copyright, and last modified date -->
	<p>&copy; <?php echo date('Y'); ?> Convenience-R-Us. All rights reserved.</p>
	<p>Last Modified: <?php echo $formattedDate; ?></p>
	<a href="valid-css.png" target="_blank"><img src="valid-css.png" alt="Valid CSS"></a>
	<a href="valid-xhtml1.png" target="_blank"><img src="valid-xhtml1.png" alt="Valid XHTML 1.0"></a>
    </footer>
</body>
</html>